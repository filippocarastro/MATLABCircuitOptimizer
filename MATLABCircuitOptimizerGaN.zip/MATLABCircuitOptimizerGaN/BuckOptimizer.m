clc;clear all;close all;
%Imposto i nomi dei path dei vari file
sim.filePath = 'C:\Users\Kreidos\Desktop\MATLABCircuitOptimizerGaN'; %This is the path to the working LTSPICE folder (schems, netlists, simulation output files)
sim.fileName='NetBuck.net';
sim.netlist_filename = [sim.filePath '\' sim.fileName]; %original netlist with param to be optimized
%Mos parameter to be opt
W1 = 84500; %default [mm]
W2 = 154500; %default [mm]
val=[W1,W2];
%fitness custom handle function
fit= @(x) fitness(x,sim);
fit([W1 W2])

%%
options = optimoptions('particleswarm','Display','Iter','SwarmSize',15,'MaxIterations',5,'MaxStallIterations',3,'UseParallel',true);
% PSO optimizer 
[x_sol,f_sol,~,~] = particleswarm(fit,2,[84500; 84500],[154500; 154500],options);

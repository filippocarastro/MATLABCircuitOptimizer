clc;clear all;close all;
%Imposto i nomi dei path dei vari file
sim.filePath = 'C:\Users\Kreidos\Desktop\MATLABCircuitOptimizerGaN'; %This is the path to the working LTSPICE folder (schems, netlists, simulation output files)
sim.fileName='NetBuck.net';
sim.netlist_filename = [sim.filePath '\' sim.fileName]; %original netlist with param to be optimized
%Mos parameter to be opt
W1 = 154500; %default [mm]
W2 = 154500; %default [mm]
%fitness custom handle function
fit= @(x) fitness(x,sim);
tic
fit([W1 W2])
toc
%%
options = optimoptions('particleswarm','UseParallel',false,'Display','Iter','SwarmSize',15,'MaxStallIterations',3);
% PSO optimizer 
tic
[x_sol,f_sol,~,~] = particleswarm(fit,2,[84500; 84500],[154500; 154500],options);
toc
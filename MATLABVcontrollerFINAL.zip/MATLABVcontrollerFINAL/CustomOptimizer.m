function [DC,cost] = CustomOptimizer(varargin)
if nargin==3
    if strcmp(varargin{1},'particleswarm')
    options = optimoptions(varargin{1},'UseParallel',varargin{3},'MaxStallIterations',5,'MaxIterations',8,'Display','Iter','SwarmSize',40);
    tic
    [DC,cost,~,~] = particleswarm(varargin{2},2,[0.1 0.1],[0.9 0.9],options);
    toc
    elseif strcmp(varargin{1},'ga')
    options = optimoptions(varargin{1},'UseParallel',varargin{3},'MaxStallIterations',5,'MaxGenerations',8,'Display','Iter','PopulationSize',40);
    tic
    [DC,cost,~,~] = ga(varargin{2},2,[],[],[0.1 0.1],[0.9 0.9],[],options);
    toc
    else
    % a custom optimizer must take in input fit function and custom optimizer defined name function (.m or MEX)
    tic
    [DC,cost]=UserOptimizer(varargin(1),varargin(2));
    toc
    end
else
    % Error nargin wrong
    error('Please, provide the correct number of input parameters.');
end
end
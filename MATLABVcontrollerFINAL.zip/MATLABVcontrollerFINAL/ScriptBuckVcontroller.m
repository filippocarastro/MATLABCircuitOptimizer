clc;clear all;
sim.LTspicepath='"C:\Users\franz\AppData\Local\Programs\ADI\LTspice\LTspice.exe"';
sim.path='C:\Users\franz\Desktop\MATLABVcontroller\NetBuckDc.net';
sim.target=6;
sim.T=2e-6;
% Defining fit function
fit= @(x) fitnessVopt(x,sim);
%  fit([0.5 0.5]) % evaluate fit
%% Parallel and serial
[DC,cost]=CustomOptimizer('particleswarm',fit,false);
[DC,cost]=CustomOptimizer('particleswarm',fit,true);


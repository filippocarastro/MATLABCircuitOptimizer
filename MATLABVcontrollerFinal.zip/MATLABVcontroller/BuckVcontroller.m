clc;clear all;close all;
%Imposto i nomi dei path dei vari file
sim.LTspicepath='"C:\Users\Kreidos\AppData\Local\Programs\ADI\LTspice\LTspice.exe"';
sim.path='C:\Users\Kreidos\Desktop\MATLABCircuitOptimizer-main\NetBuckDc.net';
sim.target=12; %target oup voltage
% %fitness custom handle function
fit= @(x) fitnessVopt(x,sim);
% % fit([0.5 0.5])
% % PSO optimizer
options = optimoptions('particleswarm','UseParallel',true,'MaxStallIterations',5,'Display','Iter','SwarmSize',40);
tic
[x_sol,f_sol,~,~] = particleswarm(fit,2,[0.1 0.1],[0.9 0.9],options);
toc

function cost = fitnessVopt(features,sim)
% Open the default netlist from paths
h = fopen(sim.path,'r');
Testo=fread(h,Inf,'*char')';
% Take the txt and replace the special characters on the default netlist (the features to be optimized)
Testo=strrep(Testo,'$Ton1',num2str(features(1)*2e-6)); 
Testo=strrep(Testo,'$Ton2',num2str(features(2)*2e-6)); 
fclose(h);
% Write the text as netlist to be simulated. Default file is not modified.
% Generate random name for the written netlist to avoid conflict wrt parallel workers
pathtmp=tempname('C:\Users\Kreidos\Desktop\MATLABCircuitOptimizer-main');
% Write netlist to be simulated
hdest=fopen([pathtmp '.net'], 'w');
fwrite(hdest,Testo,'char');
fclose(hdest);
% Netlist simulation with system (cmd). Syntax is fixed by the program.
[status,~] = system([sim.LTspicepath,' -b ','"',pathtmp,'.net"']); 
% Debug status error for the current launched LTSpice simulation.
if status 
    fprintf('ERROR, LTSpice sim failed to run.\n ');
end
% Read the text from .log file LTSpice output file
fileID = fopen([pathtmp '.log']);
Testo=fread(fileID,Inf,'*char')';
fclose(fileID);
% Extracting information required from Text file
newStr = extractAfter(Testo,'AVG(v(out))=');
Vout = sscanf(newStr,'%f');
% Defining cost.
cost= abs(Vout-sim.target); 
% Clean tmp files
% delete([pathtmp '.net'])
% delete([pathtmp '.log'])
delete([pathtmp '.raw'])
delete([pathtmp '.op.raw'])
end


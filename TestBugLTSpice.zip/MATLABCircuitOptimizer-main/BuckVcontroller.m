clc;clear all;close all;
%Imposto i nomi dei path dei vari file
% sim.LTspicepath='"C:\Users\Kreidos\AppData\Local\Programs\ADI\LTspice\LTspice.exe"';
% sim.path='C:\Users\Kreidos\Desktop\MATLABCircuitOptimizer-main\NetBuckDc.net';
% sim.target=12; %target oup voltage
% %fitness custom handle function
% fit= @(x) fitnessVopt(x,sim);
% % fit([0.5 0.5])
% % PSO optimizer
% options = optimoptions('particleswarm','UseParallel',false,'MaxStallIterations',3,'MaxIterations',5,'Display','Iter','SwarmSize',40);
% tic
% [x_sol,f_sol,~,~] = particleswarm(fit,2,[0.1 0.1],[0.9 0.9],options);
% toc
%% Prova a runnare da cmd la failNet.net che quei valori di Ton1 e Ton2

[status,~] = system(['"C:\Users\Kreidos\AppData\Local\Programs\ADI\LTspice\LTspice.exe"',' -b ','"','failNet','.net"']); 

% e poi prova a runnare i valori della netlist da spice Ton1= 1.3166e-06 Ton2= 1.1371e-06
% controlla se fallisce la simulazione